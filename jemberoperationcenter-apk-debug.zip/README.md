# Jember Operation Center – APK Debug

1. Upload semua file ini ke repo (folder `.github/workflows/build-apk.yml` harus ikut).
2. Buka tab **Actions → Build APK Debug**, tunggu hijau (±5–8 menit). Bisa juga jalankan manual lewat *Run workflow*.
3. Buka run yang selesai, unduh **app-debug** di bagian *Artifacts*, ekstrak, lalu pasang `app-debug.apk`.
4. Buka aplikasi, tekan ikon gear di layar login, isi link, simpan, lalu Masuk.

Akun login diubah di `www/config.js`.
