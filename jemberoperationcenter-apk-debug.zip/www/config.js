window.APP_CONFIG = {
  // Link bawaan (bisa diganti lewat ikon gerigi di layar login)
  defaultUrl: "https://jemberoperationcenter.ai.studio"
};
