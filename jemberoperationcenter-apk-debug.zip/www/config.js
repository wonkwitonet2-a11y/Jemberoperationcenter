// Ubah sesuai kebutuhan. CATATAN: login ini hanya di sisi browser (bukan keamanan sungguhan).
window.APP_CONFIG = {
  appName: "Jember Operation Center",
  // Daftar akun. Kosongkan ([]) kalau tidak ingin login lokal, tombol Masuk langsung membuka link.
  users: [{ username: "admin", password: "jember123" }],
  // Link bawaan (boleh kosong, bisa diisi lewat pengaturan di layar login)
  defaultUrl: "",
  // Tombol kecil "keluar" melayang setelah masuk
  showExitButton: true
};
