window.APP_CONFIG = {
  // Link bawaan (bisa diganti lewat ikon gerigi di layar login)
  defaultUrl: "https://wonkwitonet2-a11y.github.io/Jemberoperationcenter/"
};
