import React, { useState } from 'react';
import { EvaluasiRow } from '../services/evaluasi';
import { formatNumber, formatDecimal, formatPercent, getStatusClass } from '../services/storage';
import { buildBestLookup, BEST_CELL_CLASS, BestKey } from '../services/evalBest';
import { Table, LayoutGrid, ArrowRightLeft } from 'lucide-react';

interface EvalMiniTableProps {
  r1Rows: EvaluasiRow[];
  r2Rows: EvaluasiRow[];
  r1Total: EvaluasiRow;
  r2Total: EvaluasiRow;
  cabangTotal: EvaluasiRow;
  selectedRayon: number;
  mobileMode?: 'table' | 'matrix';
  onMobileModeChange?: (mode: 'table' | 'matrix') => void;
  hideTopBar?: boolean;
  compact?: boolean;
}

export const EvalMiniTable: React.FC<EvalMiniTableProps> = ({
  r1Rows,
  r2Rows,
  r1Total,
  r2Total,
  cabangTotal,
  selectedRayon,
  mobileMode: mobileModeProp,
  onMobileModeChange,
  hideTopBar = false,
  compact = false
}) => {
  // Mode tampilan mobile: 'table' (tabel geser presisi) vs 'matrix' (matriks baris rapi per unit)
  const [internalMobileMode, setInternalMobileMode] = useState<'table' | 'matrix'>('table');
  const mobileMode = mobileModeProp !== undefined ? mobileModeProp : internalMobileMode;
  const setMobileMode = (m: 'table' | 'matrix') => {
    setInternalMobileMode(m);
    if (onMobileModeChange) onMobileModeChange(m);
  };

  const activeRows = [
    ...(selectedRayon === 0 || selectedRayon === 1 ? r1Rows : []),
    ...(selectedRayon === 0 || selectedRayon === 2 ? r2Rows : []),
  ];
  const bestOf = buildBestLookup(activeRows);

  const thSubCls = compact
    ? "py-[3px] px-1 text-right font-semibold whitespace-nowrap text-[8.5px] border-b border-neutral-200 dark:border-neutral-700 leading-none"
    : "py-1 px-1 sm:py-1.5 sm:px-1.5 text-right font-semibold whitespace-nowrap text-[9.5px] sm:text-[11px] border-b border-neutral-200 dark:border-neutral-700";

  const tdCls = compact
    ? "py-[2.5px] px-1 text-right whitespace-nowrap tabular-nums font-mono text-[8.5px] leading-tight"
    : "py-1 px-1 sm:py-1.5 sm:px-1.5 text-right whitespace-nowrap tabular-nums font-mono text-[9.5px] sm:text-[11px]";

  const renderTableRow = (r: EvaluasiRow, isSubtotal = false, isTotal = false) => {
    // Tanda terbaik hanya diberikan untuk baris TKU aktif (bukan subtotal/total)
    const b = (k: BestKey) => (!isSubtotal && !isTotal && bestOf(k, r) ? ` ${BEST_CELL_CLASS}` : '');

    const rowBg = isTotal
      ? 'bg-neutral-900 text-white dark:bg-neutral-950 font-bold'
      : isSubtotal
      ? 'bg-neutral-100 dark:bg-neutral-800 font-bold text-neutral-800 dark:text-neutral-200'
      : 'hover:bg-neutral-50/90 dark:hover:bg-neutral-800/50 text-neutral-800 dark:text-neutral-200 font-medium';

    const stickyBg = isTotal
      ? 'bg-neutral-900 text-white dark:bg-neutral-950'
      : isSubtotal
      ? 'bg-neutral-100 dark:bg-neutral-800'
      : 'bg-white dark:bg-neutral-900 group-hover:bg-neutral-50 dark:group-hover:bg-neutral-800/50';

    const borderB = isTotal ? 'border-t-2 border-neutral-700' : 'border-b border-neutral-100 dark:border-neutral-800';

    return (
      <tr 
        key={r.tku.id + (isSubtotal ? '-sub' : '') + (isTotal ? '-tot' : '')} 
        className={`group transition-colors ${rowBg} ${borderB}`}
      >
        {/* Kolom TKU Sticky di Kiri */}
        <td className={`${compact ? 'px-1 py-[2.5px]' : 'px-1.5 py-1 sm:px-2 sm:py-1.5'} text-left font-sans font-semibold whitespace-nowrap sticky left-0 z-10 border-r border-neutral-200 dark:border-neutral-700 shadow-[2px_0_4px_-1px_rgba(0,0,0,0.08)] dark:shadow-[2px_0_4px_-1px_rgba(0,0,0,0.5)] ${stickyBg}`}>
          <div className={`flex items-center gap-0.5 ${compact ? 'min-w-[60px] max-w-[85px]' : 'min-w-[70px] sm:min-w-[85px] max-w-[110px]'} truncate`}>
            <span className={`truncate ${compact ? 'text-[8.5px] font-bold' : 'text-[10px] sm:text-xs'}`}>{r.tku.nama}</span>
            {!isSubtotal && !isTotal && (
              <span className={`${compact ? 'text-[7.5px] px-0.5' : 'text-[8px] sm:text-[9px] px-1'} py-0 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-500 font-normal shrink-0`}>
                R{r.tku.rayon}
              </span>
            )}
          </div>
        </td>

        {/* 1. Rata2 */}
        <td className={`${tdCls} font-bold text-neutral-900 dark:text-neutral-100 border-l border-neutral-200/60 dark:border-neutral-700/60${b('rata2')}`}>
          {formatDecimal(r.rata2)}
        </td>

        {/* 2. vs LW (%) */}
        <td className={`${tdCls}${b('vsLwPct')}`}>
          {r.vsLwPct !== null ? (
            <span className={isTotal || isSubtotal ? '' : getStatusClass(r.vsLwPct - 1)}>
              {formatPercent(r.vsLwPct)}
            </span>
          ) : (
            <span className="text-neutral-400 font-normal">—</span>
          )}
        </td>

        {/* 3. vs Tgt (%) */}
        <td className={`${tdCls}${b('vsTgPct')}`}>
          <span className={isTotal || isSubtotal ? '' : getStatusClass(r.diffTg)}>
            {formatPercent(r.vsTgPct)}
          </span>
        </td>

        {/* 4. vs LY (%) */}
        <td className={`${tdCls}${b('vsLyPct')}`}>
          <span className={isTotal || isSubtotal ? '' : getStatusClass(r.diffLy)}>
            {formatPercent(r.vsLyPct)}
          </span>
        </td>

        {/* 5. % BB */}
        <td className={`${tdCls} text-amber-600 dark:text-amber-400 font-bold border-l border-neutral-200/60 dark:border-neutral-700/60${b('pctBb')}`}>
          {formatPercent(r.pctBb)}
        </td>

        {/* 6. s/YL */}
        <td className={`${tdCls} font-bold text-brand-600 dark:text-brand-400${b('syl')}`}>
          {formatNumber(r.syl)}
        </td>

        {/* 7. Absen */}
        <td className={`${tdCls} border-l border-neutral-200/60 dark:border-neutral-700/60 text-center${b('absen')}`}>
          <span className={r.absen > 0 ? 'text-red-600 dark:text-red-400 font-bold' : 'text-neutral-400'}>
            {r.absen}
          </span>
        </td>

        {/* 8. Frek */}
        <td className={`${tdCls} text-center${b('frek')}`}>
          <span className={r.frek > 0 ? 'text-red-600 dark:text-red-400 font-bold' : 'text-neutral-400'}>
            {r.frek}
          </span>
        </td>

        {/* 9. % Cover Area (CA) */}
        <td className={`${tdCls} border-l border-neutral-200/60 dark:border-neutral-700/60 font-bold ${r.cover >= 1.0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'}${b('cover')}`}>
          {formatPercent(r.cover)}
        </td>

        {/* 10. % YL < 250 */}
        <td className={`${tdCls} border-l border-neutral-200/60 dark:border-neutral-700/60 font-bold ${r.pctL250 > 0.3 ? 'text-red-600 dark:text-red-400' : r.pctL250 > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400'}${b('pctL250')}`}>
          {formatPercent(r.pctL250)}
        </td>
      </tr>
    );
  };

  return (
    <div className="space-y-2">
      {/* Header Bar dengan Toggle Mode Tampilan di Layar Mobile (bila hideTopBar false) */}
      {!hideTopBar && (
        <div className="flex items-center justify-between gap-2 px-1">
          <div className="flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400">
            <span className="inline-block w-2 h-2 rounded-full bg-brand-500" />
            <span className="font-semibold text-neutral-700 dark:text-neutral-300">Format Mini Ringkas</span>
          </div>

          {/* Tombol Switcher Khusus Layar HP: Tabel Geser vs Matriks Ringkas */}
          <div className="sm:hidden inline-flex p-0.5 bg-neutral-100 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700">
            <button
              type="button"
              onClick={() => setMobileMode('table')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                mobileMode === 'table'
                  ? 'bg-white dark:bg-neutral-700 text-neutral-900 dark:text-white shadow-2xs'
                  : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
              }`}
            >
              <Table className="w-3 h-3 text-brand-500" />
              <span>Tabel Geser</span>
            </button>
            <button
              type="button"
              onClick={() => setMobileMode('matrix')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                mobileMode === 'matrix'
                  ? 'bg-white dark:bg-neutral-700 text-neutral-900 dark:text-white shadow-2xs'
                  : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
              }`}
            >
              <LayoutGrid className="w-3 h-3 text-brand-500" />
              <span>Matriks HP</span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAMPILAN 1: TABEL LENGKAP GESER PRESISI (BORDER SEPARATE AGAR STICKY RAPI) */}
      {/* ========================================================================= */}
      {(mobileMode === 'table' || typeof window === 'undefined') && (
        <div className="rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 shadow-sm overflow-hidden">
          {/* Petunjuk Geser Horizontal di HP */}
          <div className="sm:hidden px-2.5 py-1 bg-neutral-50 dark:bg-neutral-800/70 border-b border-neutral-200/80 dark:border-neutral-800 flex items-center justify-between text-[10px] text-neutral-600 dark:text-neutral-400">
            <span className="flex items-center gap-1 font-medium text-brand-600 dark:text-brand-400">
              <ArrowRightLeft className="w-3 h-3 shrink-0" /> Geser tabel jika diperlukan
            </span>
            <span className="font-mono text-[9px] text-neutral-400">11 Kolom</span>
          </div>

          <div className="overflow-x-auto w-full" style={{ WebkitOverflowScrolling: 'touch' }}>
            <table className="w-full text-[10px] sm:text-xs text-left border-separate border-spacing-0 table-fixed">
              <colgroup>
                <col className="w-[18%]" />
                <col className="w-[9%]" />
                <col className="w-[8.5%]" />
                <col className="w-[8.5%]" />
                <col className="w-[8.5%]" />
                <col className="w-[8.5%]" />
                <col className="w-[8%]" />
                <col className="w-[6.5%]" />
                <col className="w-[6.5%]" />
                <col className="w-[9%]" />
                <col className="w-[9%]" />
              </colgroup>
              <thead>
                {/* Header Tingkat 1: Grup Kategori Metrik */}
                <tr className="bg-neutral-100 dark:bg-neutral-800/90 text-neutral-500 text-[9px] sm:text-[10px] uppercase font-bold tracking-wider">
                  <th 
                    rowSpan={2} 
                    className="px-1.5 py-1 text-left sticky left-0 z-20 bg-neutral-100 dark:bg-neutral-800 border-r border-b border-neutral-200 dark:border-neutral-700 shadow-[2px_0_4px_-1px_rgba(0,0,0,0.08)] dark:shadow-[2px_0_4px_-1px_rgba(0,0,0,0.5)] truncate"
                  >
                    TKU
                  </th>
                  <th colSpan={4} className="py-1 px-1.5 text-center border-l border-b border-neutral-200 dark:border-neutral-700 bg-brand-50/50 dark:bg-brand-950/20 text-brand-700 dark:text-brand-300">
                    Capaian Penjualan
                  </th>
                  <th colSpan={2} className="py-1 px-1.5 text-center border-l border-b border-neutral-200 dark:border-neutral-700 bg-amber-50/50 dark:bg-amber-950/20 text-amber-700 dark:text-amber-300">
                    Mutu &amp; s/YL
                  </th>
                  <th colSpan={2} className="py-1 px-1.5 text-center border-l border-b border-neutral-200 dark:border-neutral-700 bg-neutral-100 dark:bg-neutral-800">
                    Presensi YL
                  </th>
                  <th colSpan={2} className="py-1 px-1.5 text-center border-l border-b border-neutral-200 dark:border-neutral-700 bg-emerald-50/40 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-300">
                    Area &amp; Produktivitas
                  </th>
                </tr>

                {/* Header Tingkat 2: Nama Kolom */}
                <tr className="bg-neutral-50 dark:bg-neutral-800/60 text-neutral-600 dark:text-neutral-300">
                  <th className={`${thSubCls} border-l border-neutral-200 dark:border-neutral-700 font-bold text-neutral-900 dark:text-neutral-100`}>Rata2</th>
                  <th className={thSubCls}>vs LW</th>
                  <th className={thSubCls}>vs Tgt</th>
                  <th className={thSubCls}>vs LY</th>
                  <th className={`${thSubCls} border-l border-neutral-200 dark:border-neutral-700 text-amber-600 dark:text-amber-400`}>% BB</th>
                  <th className={`${thSubCls} text-brand-600 dark:text-brand-400`}>s/YL</th>
                  <th className={`${thSubCls} border-l border-neutral-200 dark:border-neutral-700 text-center`}>Abs</th>
                  <th className={`${thSubCls} text-center`}>Frk</th>
                  <th className={`${thSubCls} border-l border-neutral-200 dark:border-neutral-700`}>% CA</th>
                  <th className={`${thSubCls} border-l border-neutral-200 dark:border-neutral-700 text-brand-600 dark:text-brand-400`}>&lt;250</th>
                </tr>
              </thead>
              <tbody>
                {/* Rayon 1 */}
                {(selectedRayon === 0 || selectedRayon === 1) && (
                  <>
                    {r1Rows.map(r => renderTableRow(r))}
                    {renderTableRow(r1Total, true)}
                  </>
                )}

                {/* Rayon 2 */}
                {(selectedRayon === 0 || selectedRayon === 2) && (
                  <>
                    {r2Rows.map(r => renderTableRow(r))}
                    {renderTableRow(r2Total, true)}
                  </>
                )}
              </tbody>
              {selectedRayon === 0 && (
                <tfoot>
                  {renderTableRow(cabangTotal, false, true)}
                </tfoot>
              )}
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAMPILAN 2: MATRIKS RAPI PER UNIT TKU KHUSUS HP (TERATUR & SANGAT MUDAH DIBACA) */}
      {/* ========================================================================= */}
      {mobileMode === 'matrix' && (
        <div className="space-y-3 sm:hidden animate-in fade-in duration-150">
          {activeRows.map(r => {
            const isTargetHit = r.diffTg >= 0;
            const b = (k: BestKey) => (bestOf(k, r) ? ` ${BEST_CELL_CLASS} rounded px-1` : '');

            return (
              <div 
                key={r.tku.id} 
                className="p-3.5 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 shadow-2xs space-y-2.5"
              >
                {/* Baris Atas: Nama Unit & Angka Rata2 + Capaian Target */}
                <div className="flex items-center justify-between gap-2 border-b border-neutral-100 dark:border-neutral-800 pb-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="w-5 h-5 rounded-md bg-brand-600 text-white font-bold text-[10px] flex items-center justify-center shrink-0">
                      R{r.tku.rayon}
                    </span>
                    <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100 truncate">
                      {r.tku.nama}
                    </h3>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <span className="text-xs font-mono font-black text-neutral-900 dark:text-white">
                      {formatDecimal(r.rata2)} <span className="text-[10px] font-normal text-neutral-400">btl</span>
                    </span>
                    <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-md ${
                      isTargetHit 
                        ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800' 
                        : 'bg-brand-50 text-brand-700 dark:bg-brand-950/40 dark:text-brand-400 border border-brand-200 dark:border-brand-800'
                    }`}>
                      {formatPercent(r.vsTgPct)}
                    </span>
                  </div>
                </div>

                {/* Matriks 4 Kolom Teratur: Seluruh Indikator Berada di Posisi Identik */}
                <div className="grid grid-cols-4 gap-1.5 text-center text-[10px] font-mono">
                  {/* Kolom 1: Tren Pertumbuhan */}
                  <div className="p-2 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-100 dark:border-neutral-800 space-y-1">
                    <span className="text-[9px] uppercase font-bold text-neutral-400 block tracking-tight">Tren</span>
                    <div>
                      <span className="text-[9px] text-neutral-400 block">vs LW</span>
                      <span className={`font-bold block ${getStatusClass(r.vsLwPct !== null ? r.vsLwPct - 1 : 0)}${b('vsLwPct')}`}>
                        {r.vsLwPct !== null ? formatPercent(r.vsLwPct) : '—'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[9px] text-neutral-400 block">vs LY</span>
                      <span className={`font-bold block ${getStatusClass(r.diffLy)}${b('vsLyPct')}`}>
                        {formatPercent(r.vsLyPct)}
                      </span>
                    </div>
                  </div>

                  {/* Kolom 2: Mutu Botol & s/YL */}
                  <div className="p-2 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-100 dark:border-neutral-800 space-y-1">
                    <span className="text-[9px] uppercase font-bold text-neutral-400 block tracking-tight">Mutu</span>
                    <div>
                      <span className="text-[9px] text-neutral-400 block">% BB</span>
                      <span className={`font-bold text-amber-600 dark:text-amber-400 block${b('pctBb')}`}>
                        {formatPercent(r.pctBb)}
                      </span>
                    </div>
                    <div>
                      <span className="text-[9px] text-neutral-400 block">s/YL</span>
                      <span className={`font-bold text-brand-600 dark:text-brand-400 block${b('syl')}`}>
                        {formatNumber(r.syl)}
                      </span>
                    </div>
                  </div>

                  {/* Kolom 3: Presensi */}
                  <div className="p-2 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-100 dark:border-neutral-800 space-y-1">
                    <span className="text-[9px] uppercase font-bold text-neutral-400 block tracking-tight">Presensi</span>
                    <div>
                      <span className="text-[9px] text-neutral-400 block">Absen</span>
                      <span className={`font-bold block ${r.absen > 0 ? 'text-red-600' : 'text-neutral-600 dark:text-neutral-400'}${b('absen')}`}>
                        {r.absen}
                      </span>
                    </div>
                    <div>
                      <span className="text-[9px] text-neutral-400 block">Frek</span>
                      <span className={`font-bold block ${r.frek > 0 ? 'text-red-600' : 'text-neutral-600 dark:text-neutral-400'}${b('frek')}`}>
                        {r.frek}
                      </span>
                    </div>
                  </div>

                  {/* Kolom 4: Evaluasi Area & YL */}
                  <div className="p-2 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-100 dark:border-neutral-800 space-y-1">
                    <span className="text-[9px] uppercase font-bold text-neutral-400 block tracking-tight">Evaluasi</span>
                    <div>
                      <span className="text-[9px] text-neutral-400 block">% CA</span>
                      <span className={`font-bold block ${r.cover >= 1 ? 'text-emerald-600' : 'text-amber-600'}${b('cover')}`}>
                        {formatPercent(r.cover)}
                      </span>
                    </div>
                    <div>
                      <span className="text-[9px] text-neutral-400 block">&lt;250</span>
                      <span className={`font-bold block ${r.pctL250 > 0 ? 'text-red-600' : 'text-emerald-600'}${b('pctL250')}`}>
                        {formatPercent(r.pctL250)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {/* Kartu Ringkasan Total Cabang di Mode Matriks HP */}
          <div className="p-4 rounded-2xl bg-neutral-900 text-white dark:bg-neutral-950 border border-neutral-800 shadow-md space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs uppercase tracking-wider text-neutral-300">TOTAL CABANG JEMBER</span>
              <span className="text-xs font-mono font-bold text-emerald-400">
                {formatPercent(cabangTotal.vsTgPct)} vs Target
              </span>
            </div>
            <div className="grid grid-cols-4 gap-1 text-center text-[10px] font-mono pt-1 border-t border-neutral-800">
              <div>
                <span className="text-neutral-400 text-[9px] block">Rata/Hari</span>
                <span className="font-bold text-xs text-white">{formatDecimal(cabangTotal.rata2)}</span>
              </div>
              <div>
                <span className="text-neutral-400 text-[9px] block">% BB</span>
                <span className="font-bold text-xs text-amber-400">{formatPercent(cabangTotal.pctBb)}</span>
              </div>
              <div>
                <span className="text-neutral-400 text-[9px] block">s/YL</span>
                <span className="font-bold text-xs text-brand-400">{formatNumber(cabangTotal.syl)}</span>
              </div>
              <div>
                <span className="text-neutral-400 text-[9px] block">% CA</span>
                <span className="font-bold text-xs text-emerald-400">{formatPercent(cabangTotal.cover)}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Catatan / Legend Resmi di Bagian Bawah */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 bg-neutral-50 dark:bg-neutral-800/40 rounded-xl border border-neutral-200/60 dark:border-neutral-800 text-[11px] text-neutral-500">
        <div className="flex items-center gap-1.5">
          <span className="inline-block w-3 h-3 rounded bg-emerald-100 dark:bg-emerald-900/50 border border-emerald-500" />
          <span><strong className="text-emerald-700 dark:text-emerald-400">Sel hijau</strong> = Performa terbaik unit TKU</span>
        </div>
      </div>
    </div>
  );
};
